package View;

/*
 Role : Username
 Username : user1
 Password :456
 
 Role : Admin
 Username : duync
 Password : 345
 
 Role : Clerk
 Username : sa
 Password :123
 */


import java.util.Scanner;

import Controller.Login;
import Controller.Register;

public class MainApp {
	public static void menu() {
		String etc = "";
		System.out.printf("\n\n%10s************************************************************\n", etc);
		System.out.printf("%10s*%58s*\n", etc, etc);
		System.out.printf("%10s*-----------------!! HOTEL MANAGE SYSTEM !!----------------*\n", etc);
		System.out.printf("%10s*%58s*\n", etc, etc);

		System.out.printf("%10s*\t1. LOGIN%45s*\n", etc, etc);
		System.out.printf("%10s*\t2. REGISTER_USERS%36s*\n", etc, etc);
		System.out.printf("%10s*\t3. BACK%46s*\n", etc, etc);
		System.out.printf("%10s*\t0. EXIT%46s*\n", etc, etc);
		System.out.printf("%10s************************************************************\n", etc);
	}


	public static void main(String[] args)  {
		int n = 0;
		Scanner input = new Scanner(System.in);
		int chon;
		do {
			menu();
			chon = input.nextInt();

			switch (chon) {
			case 1:
				Login.LoginAccount();
				break;
			case 2:
				Register.registerAccount();
				break;
			case 3:
				MainApp.menu();
				break;
			case 0:
				System.exit(0);
			
			default:
				System.out.println("Chon tu 1->3");
			}
		} while(chon ==0);
	}

}

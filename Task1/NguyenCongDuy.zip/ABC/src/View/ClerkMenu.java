package View;

import java.sql.SQLException;
import java.util.Scanner;

import Controller.CreateUsers;
import Controller.Search;
import Controller.UpdateStatusRoom;
import Controller.ViewAllRoom;

public class ClerkMenu {
	public static void  menu() throws ClassNotFoundException, SQLException {
		String etc = "";
		System.out.printf("\n\n%10s************************************************************\n", etc);
		System.out.printf("%10s*%58s*\n", etc, etc);
		System.out.printf("%10s*---------------------!! CLERK MENU  !!--------------------*\n", etc);
		System.out.printf("%10s*%58s*\n", etc, etc);

		System.out.printf("%10s*\t1. VIEW ALL ROOM%37s*\n", etc, etc);
		System.out.printf("%10s*\t2. SEARCH%44s*\n", etc, etc);
		System.out.printf("%10s*\t3. UPDATE STATUS ROOM%32s*\n", etc, etc);
		System.out.printf("%10s*\t4. BACK%46s*\n", etc, etc);
		System.out.printf("%10s*\t0. EXIT%46s*\n", etc, etc);
		System.out.printf("%10s************************************************************\n", etc);

		Scanner input = new Scanner(System.in);
		int chon;
		do {
//		menu();
			chon = input.nextInt();
			switch (chon) {
			case 1:
				ViewAllRoom.ViewRoom();
				break;
			case 2:
				Search.SearchRoom();
				break;
			case 3:
				UpdateStatusRoom.Update();
				break;
			case 4:
				ClerkMenu.menu();
				break;
			case 0:
				System.exit(0);
			default:
				break;
			}
		} while (chon != 0);
	}

	public static void main(String[] args) {

	}
}

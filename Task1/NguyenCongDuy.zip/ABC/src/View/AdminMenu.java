package View;

import java.util.Scanner;

import Controller.CreateUsers;
import Controller.SetRoleAdmin;

public class AdminMenu {
	public static void menu() {
		String etc = "";
		System.out.printf("\n\n%10s************************************************************\n", etc);
		System.out.printf("%10s*%58s*\n", etc, etc);
		System.out.printf("%10s*----------------------!! ADMIN MENU !!--------------------*\n", etc);
		System.out.printf("%10s*%58s*\n", etc, etc);

		System.out.printf("%10s*\t1. CREATE_NEW_USER%35s*\n", etc, etc);
		System.out.printf("%10s*\t2. SET_ROLE%42s*\n", etc, etc);
		System.out.printf("%10s*\t3. BACK%46s*\n", etc, etc);
		System.out.printf("%10s*\t0. EXIT%46s*\n", etc, etc);
		System.out.printf("%10s************************************************************\n", etc);
//		int n=0;
		Scanner input = new Scanner(System.in);
		int chon;
		do {
//			menu();
			chon = input.nextInt();
			switch (chon) {
			case 1:
				CreateUsers.CreateUsers();
				break;
			case 2:
				SetRoleAdmin.main(null);
			case 3 :
				AdminMenu.menu();
			
			case 0:
				System.exit(0);
			default:
				break;
			}
		} while (chon !=0);
	}
	public static void main(String[] args) {

	}
}

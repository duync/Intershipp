package Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Scanner;

import Entities.Room;
import Model.ConnectionUtils;

public class Search {
	static ResultSet rs = null;

	static Scanner input = new Scanner(System.in);

	public static void SearchRoom() {
		ArrayList<Room> list = new ArrayList<>();
		String sql = "SELECT * FROM ROOM";
		String sql2 = "select * from ROOM where RoomID = ?";

		try {
			Connection conn = ConnectionUtils.getMyConnection();
			PreparedStatement stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();
			while (rs.next()) {
				Room room = new Room();
				room.setRoomID(rs.getInt("RoomID"));
				room.setMaPhong(rs.getString("MaPhong"));
				room.setTenPhong(rs.getString("TenPhong"));
				room.setGia(rs.getString("Gia"));
				room.setTrangThai(rs.getBoolean("TrangThai"));
				list.add(room);
			}
			String leftAlignFormat = "| %-13s | %-10s  | %-10s  | %-10s  | %-6s  | %n";
			System.out.format("+---------------+-------------+-------------+-------------+---------+%n");
			System.out.format("| RoomID        | MaPhong     |   TenPhong  | Gia         |TrangThai|%n");
			System.out.format("+---------------+-------------+-------------+-------------+---------+%n");
			for (Room room : list) {
				System.out.printf(leftAlignFormat, room.getRoomID(), room.getMaPhong(), room.getTenPhong(),
						room.getGia(), room.isTrangThai());
				System.out.format("+---------------+-------------+-------------+-------------+---------+%n");
			}
			
			//show danh sách phòng 
			System.out.println("Nhập mã phòng bạn cần tìm:");
			String MaPhong = input.nextLine();
			for (int i = 0; i < list.size(); i++) {
				if(list.get(i).getMaPhong().equals(MaPhong)) {
					System.out.println("Phòng bạn cần tìm là :");
					System.out.println("RoomID: "+list.get(i).getRoomID());
					System.out.println("Mã Phòng: "+list.get(i).getMaPhong());
					System.out.println("Tên Phòng: "+list.get(i).getTenPhong());
					System.out.println("Trạng thái: "+list.get(i).isTrangThai());
				}
			}
		} catch (Exception e) {
			System.out.println(e);

		}
	}
}

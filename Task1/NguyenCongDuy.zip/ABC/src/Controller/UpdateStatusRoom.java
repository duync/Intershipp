package Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import Entities.Room;
import Model.ConnectionUtils;

public class UpdateStatusRoom {
	static ResultSet rs = null;

	static Scanner input = new Scanner(System.in);

	public static void Update() throws ClassNotFoundException, SQLException {
		ArrayList<Room> list = new ArrayList<>();
		String sql = "SELECT * FROM ROOM";
		String sql2 = "select * from ROOM where RoomID = ?";
		String sql3 = "Update ROOM set TrangThai= ? where RoomID =? ";
		Connection conn = ConnectionUtils.getMyConnection();
		ViewAllRoom.ViewRoom();
		boolean a = true;
		do {
			System.out.println("Vui lòng nhập vào số ID bạn muốn cập nhật : ");
			String RoomID = input.nextLine();
			if (RoomID.equals("")) {
				System.out.println("Vui lòng nhập số ID : ");
				a = true;
			} else {
				PreparedStatement stm = conn.prepareStatement(sql2);
				stm.setString(1, RoomID);
				rs = stm.executeQuery();
				if (rs.next()) {
					System.out.println(rs.getString(2));
					Boolean trangThai = null;
					boolean cont = true;
					do {
						System.out.println("+-------------------------------------------------------------------+");
						System.out.println("|******************* - Chuyển quyền trang thai - *******************|");
						System.out.println("|**********************     ## ## ##         ***********************|");
						System.out.println("| 1.  True                                                          |");
						System.out.println("| 2.  False                                                         |");
						System.out.println("+-------------------------------------------------------------------+");
						System.out.println("Vui lòng chọn Role bạn muốn cập nhật : ");
						int i = Integer.parseInt(input.nextLine());
						switch (i) {
						case 1: {
							trangThai = true;
							cont = false;
						}
							break;
						case 2: {
							trangThai = false;
							cont = false;
						}
							break;
						}
					} while (cont);
					PreparedStatement prs = conn.prepareStatement(sql3);
					prs.setString(2, RoomID);
					prs.setBoolean(1, trangThai);
					prs.executeUpdate();
					System.out.println("Cập nhật thành công !");
					a = false;
				} else {
					System.out.println("Không tồn tại người dùng này có số thứ tự : " + RoomID);
					a = true;
				}

			}

		} while (a);

	}

}

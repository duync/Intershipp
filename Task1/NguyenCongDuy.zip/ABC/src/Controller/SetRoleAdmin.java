/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import java.util.Scanner;

import Entities.Username;
import Model.ConnectionUtils;

public class SetRoleAdmin {

	static ResultSet rs = null;

	static Scanner input = new Scanner(System.in);

	public static void main(String[] args) {
		ArrayList<Username> list = new ArrayList<>();
		String sql = "SELECT * FROM ACCOUNT";
		String sql2 = "select * from ACCOUNT where UserID = ?";
		String sql3 = "Update ACCOUNT set role= ? where UserID =? ";
		try {
			Connection conn = ConnectionUtils.getMyConnection();
			PreparedStatement stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();
			while (rs.next()) {
				Username acc = new Username();
				acc.setUserID(rs.getInt("UserID"));
				acc.setUsername(rs.getString("Username"));
				acc.setPassword(rs.getString("Password"));
				acc.setRole(rs.getString("Role"));
				list.add(acc);
			}
			String leftAlignFormat = "| %-13s | %-10s  | %-10s  | %-10s  | %-6s  | %n";
			System.out.format("+---------------+-------------+-------------+-------------+---------+%n");
			System.out.format("| RoomID        | MaPhong     |   TenPhong  | Gia         |TrangThai|%n");
			System.out.format("+---------------+-------------+-------------+-------------+---------+%n");
			for (Username acc : list) {
				System.out.printf(leftAlignFormat, acc.getUserID(), acc.getUsername(), acc.getPassword(),
						acc.getRole());
				System.out.format("+---------------+-------------+-------------+-------------+---------+%n");
			}

			// Show danh sách Room
			boolean a = true;
			do {
				System.out.println("Vui lòng nhập vào số ID bạn muốn cập nhật : ");
				String UserID = input.nextLine();
				if (UserID.equals("")) {
					System.out.println("Vui lòng nhập số ID : ");
					a = true;
				} else {
					PreparedStatement stm = conn.prepareStatement(sql2);
					stm.setString(1, UserID);
					rs = stm.executeQuery();
					if (rs.next()) {
						System.out.println(rs.getString(2));
						String role = null;
						boolean cont = true;
						do {
							System.out.println("+-------------------------------------------------------------------+");
							System.out.println("|********************** - Chuyển quyền Role - **********************|");
							System.out.println("|**********************     ## ## ##         ***********************|");
							System.out.println("| 1.  Nhân Viên                                                     |");
							System.out.println("| 2.  Khách Hàng                                                    |");
							System.out.println("+-------------------------------------------------------------------+");
							System.out.println("Vui lòng chọn Role bạn muốn cập nhật : ");
							int i = Integer.parseInt(input.nextLine());
							switch (i) {
							case 1: {
								role = "clerk";

								cont = false;
							}
								break;
							case 2: {
								role = "user";
								cont = false;
							}
								break;
							}

						} while (cont);
						PreparedStatement prs = conn.prepareStatement(sql3);
						prs.setString(1, role);
						prs.setString(2, UserID);
						prs.executeUpdate();
						System.out.println("Cập nhật thành công !");
						a = false;
					} else {
						System.out.println("Không tồn tại người dùng này có số thứ tự : " + UserID);
						a = true;
					}

				}

			} while (a);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}

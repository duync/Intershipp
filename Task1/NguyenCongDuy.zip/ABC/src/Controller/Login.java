package Controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import Model.ConnectionUtils;
import View.AdminMenu;
import View.ClerkMenu;
import View.MainApp;

public class Login {
	public static void LoginAccount() {

		Scanner input = new Scanner(System.in);
		System.out.println("Nhập tên đăng nhập: ");
		String username = input.nextLine();
		System.out.println("Nhập password");
		String password = input.nextLine();
		try {
			if (username.equals("") && password.equals("")) {
				System.out.println("Vui lòng nhập đủ thông tin");
			} else {
				Connection conn = ConnectionUtils.getMyConnection();
				String sql = "SELECT * FROM ACCOUNT WHERE Username=? AND Password=?";
				PreparedStatement stm = conn.prepareStatement(sql);
				stm.setString(1, username);
				stm.setString(2, password);
				ResultSet rs = stm.executeQuery();

				String user, pass, role;
				boolean flag = false;
				if (rs.next()) {

					flag = true;
					role = rs.getString("role");
					if (role.equals("clerk")) {
						System.out.println("Xin chào clerk");
						ClerkMenu.menu();
					} else if (role.equals("admin")) {
						System.out.println("Xin chào admin");
						AdminMenu.menu();
					} else if (role.equals("user")) {
						System.out.println("Xin chào User");
						BookRoom.Book();
					}

				} else {
					System.out.println("Login thất bại");
					MainApp.main(null);
					
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}

	}
}

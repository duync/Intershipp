package Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

import Model.ConnectionUtils;

public class CreateUsers {
	public static void CreateUsers() {
		try {
			Scanner input =  new Scanner(System.in);
			Connection conn = ConnectionUtils.getMyConnection();
			String sql = "INSERT INTO ACCOUNT(username,password,role) values(?,?,'cleck')";
			// Tạo account chỉ set role cho clerk
			PreparedStatement stmt = conn.prepareStatement(sql);
			System.out.println("Nhập tên đăng ký");
			String username = input.nextLine();
			System.out.println("Nhập mật khẩu");
			String password = input.nextLine();
			stmt.setString(1, username);
			stmt.setString(2,password);
			
			stmt.execute();
			System.out.println("Đăng ký thành công");
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
